﻿namespace WinFormsApp1
{
    partial class Product
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            groupBox1 = new GroupBox();
            btnReport = new Button();
            btnInventory = new Button();
            btnSales = new Button();
            btnProduct = new Button();
            btnAttributes = new Button();
            btnBrands = new Button();
            btnCategory = new Button();
            pictureBox1 = new PictureBox();
            btnDashboard = new Button();
            label1 = new Label();
            txtProductName = new TextBox();
            label2 = new Label();
            label3 = new Label();
            textBox2 = new TextBox();
            label4 = new Label();
            txtAttribute = new TextBox();
            label5 = new Label();
            textBox4 = new TextBox();
            btnAdd = new Button();
            label6 = new Label();
            dataProductList = new DataGridView();
            label8 = new Label();
            txtWarehouse = new TextBox();
            label10 = new Label();
            txtQuantity = new TextBox();
            label11 = new Label();
            txtPrice = new TextBox();
            label12 = new Label();
            txtSearch = new TextBox();
            colProduct = new DataGridViewTextBoxColumn();
            colCategory = new DataGridViewTextBoxColumn();
            colBrand = new DataGridViewTextBoxColumn();
            colAttribute = new DataGridViewTextBoxColumn();
            colPrice = new DataGridViewTextBoxColumn();
            colQuantity = new DataGridViewTextBoxColumn();
            colWarehouse = new DataGridViewTextBoxColumn();
            btnEdit = new Button();
            btnDelete = new Button();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataProductList).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Chartreuse;
            groupBox1.Controls.Add(btnReport);
            groupBox1.Controls.Add(btnInventory);
            groupBox1.Controls.Add(btnSales);
            groupBox1.Controls.Add(btnProduct);
            groupBox1.Controls.Add(btnAttributes);
            groupBox1.Controls.Add(btnBrands);
            groupBox1.Controls.Add(btnCategory);
            groupBox1.Controls.Add(pictureBox1);
            groupBox1.Controls.Add(btnDashboard);
            groupBox1.Location = new Point(2, 3);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(239, 864);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "groupBox1";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // btnReport
            // 
            btnReport.BackColor = Color.Chartreuse;
            btnReport.FlatAppearance.BorderSize = 0;
            btnReport.FlatStyle = FlatStyle.Flat;
            btnReport.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnReport.ForeColor = Color.Purple;
            btnReport.Location = new Point(0, 784);
            btnReport.Name = "btnReport";
            btnReport.Size = new Size(239, 80);
            btnReport.TabIndex = 15;
            btnReport.Text = "REPORT";
            btnReport.UseVisualStyleBackColor = false;
            // 
            // btnInventory
            // 
            btnInventory.BackColor = Color.Chartreuse;
            btnInventory.FlatAppearance.BorderSize = 0;
            btnInventory.FlatStyle = FlatStyle.Flat;
            btnInventory.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnInventory.ForeColor = Color.Purple;
            btnInventory.Location = new Point(0, 698);
            btnInventory.Name = "btnInventory";
            btnInventory.Size = new Size(239, 80);
            btnInventory.TabIndex = 14;
            btnInventory.Text = "INVENTORY";
            btnInventory.UseVisualStyleBackColor = false;
            // 
            // btnSales
            // 
            btnSales.BackColor = Color.Chartreuse;
            btnSales.FlatAppearance.BorderSize = 0;
            btnSales.FlatStyle = FlatStyle.Flat;
            btnSales.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSales.ForeColor = Color.Purple;
            btnSales.Location = new Point(0, 612);
            btnSales.Name = "btnSales";
            btnSales.Size = new Size(239, 80);
            btnSales.TabIndex = 13;
            btnSales.Text = "SALES";
            btnSales.UseVisualStyleBackColor = false;
            // 
            // btnProduct
            // 
            btnProduct.BackColor = Color.Chartreuse;
            btnProduct.FlatAppearance.BorderSize = 0;
            btnProduct.FlatStyle = FlatStyle.Flat;
            btnProduct.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnProduct.ForeColor = Color.Purple;
            btnProduct.Location = new Point(0, 526);
            btnProduct.Name = "btnProduct";
            btnProduct.Size = new Size(239, 80);
            btnProduct.TabIndex = 5;
            btnProduct.Text = "PRODUCT";
            btnProduct.UseVisualStyleBackColor = false;
            // 
            // btnAttributes
            // 
            btnAttributes.BackColor = Color.Chartreuse;
            btnAttributes.FlatAppearance.BorderSize = 0;
            btnAttributes.FlatStyle = FlatStyle.Flat;
            btnAttributes.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAttributes.ForeColor = Color.Purple;
            btnAttributes.Location = new Point(0, 440);
            btnAttributes.Name = "btnAttributes";
            btnAttributes.Size = new Size(239, 80);
            btnAttributes.TabIndex = 4;
            btnAttributes.Text = "ATTRIBUTES";
            btnAttributes.UseVisualStyleBackColor = false;
            // 
            // btnBrands
            // 
            btnBrands.BackColor = Color.Chartreuse;
            btnBrands.FlatAppearance.BorderSize = 0;
            btnBrands.FlatStyle = FlatStyle.Flat;
            btnBrands.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBrands.ForeColor = Color.Purple;
            btnBrands.Location = new Point(0, 354);
            btnBrands.Name = "btnBrands";
            btnBrands.Size = new Size(239, 80);
            btnBrands.TabIndex = 3;
            btnBrands.Text = "BRANDS";
            btnBrands.UseVisualStyleBackColor = false;
            // 
            // btnCategory
            // 
            btnCategory.BackColor = Color.Chartreuse;
            btnCategory.FlatAppearance.BorderSize = 0;
            btnCategory.FlatStyle = FlatStyle.Flat;
            btnCategory.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCategory.ForeColor = Color.Purple;
            btnCategory.Location = new Point(0, 268);
            btnCategory.Name = "btnCategory";
            btnCategory.Size = new Size(239, 80);
            btnCategory.TabIndex = 2;
            btnCategory.Text = "CATEGORY";
            btnCategory.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = PuffSiteInvSys.Properties.Resources.Puff_Site_Logo;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(239, 177);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // btnDashboard
            // 
            btnDashboard.BackColor = Color.Chartreuse;
            btnDashboard.FlatAppearance.BorderSize = 0;
            btnDashboard.FlatStyle = FlatStyle.Flat;
            btnDashboard.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDashboard.ForeColor = Color.Purple;
            btnDashboard.Location = new Point(0, 182);
            btnDashboard.Name = "btnDashboard";
            btnDashboard.Size = new Size(239, 80);
            btnDashboard.TabIndex = 0;
            btnDashboard.Text = "DASHBOARD";
            btnDashboard.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(262, 27);
            label1.Name = "label1";
            label1.Size = new Size(149, 31);
            label1.TabIndex = 2;
            label1.Text = "Add Product";
            // 
            // txtProductName
            // 
            txtProductName.Font = new Font("Segoe UI", 10.2F);
            txtProductName.Location = new Point(401, 90);
            txtProductName.Name = "txtProductName";
            txtProductName.Size = new Size(125, 30);
            txtProductName.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10.2F);
            label2.Location = new Point(270, 93);
            label2.Name = "label2";
            label2.Size = new Size(125, 23);
            label2.TabIndex = 4;
            label2.Text = "Product Name:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10.2F);
            label3.Location = new Point(665, 130);
            label3.Name = "label3";
            label3.Size = new Size(66, 23);
            label3.TabIndex = 6;
            label3.Text = "Brands:";
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Segoe UI", 10.2F);
            textBox2.Location = new Point(737, 126);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(125, 30);
            textBox2.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10.2F);
            label4.Location = new Point(649, 166);
            label4.Name = "label4";
            label4.Size = new Size(82, 23);
            label4.TabIndex = 8;
            label4.Text = "Attribute:";
            // 
            // txtAttribute
            // 
            txtAttribute.Font = new Font("Segoe UI", 10.2F);
            txtAttribute.Location = new Point(737, 162);
            txtAttribute.Name = "txtAttribute";
            txtAttribute.Size = new Size(125, 30);
            txtAttribute.TabIndex = 7;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10.2F);
            label5.Location = new Point(648, 93);
            label5.Name = "label5";
            label5.Size = new Size(83, 23);
            label5.TabIndex = 10;
            label5.Text = "Category:";
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Segoe UI", 10.2F);
            textBox4.Location = new Point(737, 90);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(125, 30);
            textBox4.TabIndex = 9;
            // 
            // btnAdd
            // 
            btnAdd.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAdd.Location = new Point(1076, 146);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(91, 43);
            btnAdd.TabIndex = 11;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(294, 256);
            label6.Name = "label6";
            label6.Size = new Size(130, 28);
            label6.TabIndex = 12;
            label6.Text = "Product List:";
            // 
            // dataProductList
            // 
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = SystemColors.Control;
            dataGridViewCellStyle4.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            dataProductList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            dataProductList.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataProductList.Columns.AddRange(new DataGridViewColumn[] { colProduct, colCategory, colBrand, colAttribute, colPrice, colQuantity, colWarehouse });
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = SystemColors.Window;
            dataGridViewCellStyle5.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle5.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.False;
            dataProductList.DefaultCellStyle = dataGridViewCellStyle5;
            dataProductList.Location = new Point(294, 300);
            dataProductList.Name = "dataProductList";
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = SystemColors.Control;
            dataGridViewCellStyle6.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle6.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.True;
            dataProductList.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            dataProductList.RowHeadersWidth = 51;
            dataProductList.Size = new Size(927, 555);
            dataProductList.TabIndex = 13;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 10.2F);
            label8.Location = new Point(956, 94);
            label8.Name = "label8";
            label8.Size = new Size(99, 23);
            label8.TabIndex = 15;
            label8.Text = "Warehouse:";
            // 
            // txtWarehouse
            // 
            txtWarehouse.Font = new Font("Segoe UI", 10.2F);
            txtWarehouse.Location = new Point(1061, 90);
            txtWarehouse.Name = "txtWarehouse";
            txtWarehouse.Size = new Size(125, 30);
            txtWarehouse.TabIndex = 14;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 10.2F);
            label10.Location = new Point(315, 165);
            label10.Name = "label10";
            label10.Size = new Size(80, 23);
            label10.TabIndex = 21;
            label10.Text = "Quantity:";
            // 
            // txtQuantity
            // 
            txtQuantity.Font = new Font("Segoe UI", 10.2F);
            txtQuantity.Location = new Point(401, 162);
            txtQuantity.Name = "txtQuantity";
            txtQuantity.Size = new Size(125, 30);
            txtQuantity.TabIndex = 20;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 10.2F);
            label11.Location = new Point(344, 129);
            label11.Name = "label11";
            label11.Size = new Size(51, 23);
            label11.TabIndex = 19;
            label11.Text = "Price:";
            // 
            // txtPrice
            // 
            txtPrice.Font = new Font("Segoe UI", 10.2F);
            txtPrice.Location = new Point(401, 126);
            txtPrice.Name = "txtPrice";
            txtPrice.Size = new Size(125, 30);
            txtPrice.TabIndex = 18;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.Location = new Point(1022, 262);
            label12.Name = "label12";
            label12.Size = new Size(68, 25);
            label12.TabIndex = 24;
            label12.Text = "Search:";
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(1096, 260);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(125, 27);
            txtSearch.TabIndex = 25;
            // 
            // colProduct
            // 
            colProduct.HeaderText = "Product";
            colProduct.MinimumWidth = 6;
            colProduct.Name = "colProduct";
            colProduct.Width = 125;
            // 
            // colCategory
            // 
            colCategory.HeaderText = "Category";
            colCategory.MinimumWidth = 6;
            colCategory.Name = "colCategory";
            colCategory.Width = 125;
            // 
            // colBrand
            // 
            colBrand.HeaderText = "Brand";
            colBrand.MinimumWidth = 6;
            colBrand.Name = "colBrand";
            colBrand.Width = 125;
            // 
            // colAttribute
            // 
            colAttribute.HeaderText = "Attribute";
            colAttribute.MinimumWidth = 6;
            colAttribute.Name = "colAttribute";
            colAttribute.Width = 125;
            // 
            // colPrice
            // 
            colPrice.HeaderText = "Price";
            colPrice.MinimumWidth = 6;
            colPrice.Name = "colPrice";
            colPrice.Width = 125;
            // 
            // colQuantity
            // 
            colQuantity.HeaderText = "Quantity";
            colQuantity.MinimumWidth = 6;
            colQuantity.Name = "colQuantity";
            colQuantity.Width = 125;
            // 
            // colWarehouse
            // 
            colWarehouse.HeaderText = "Warehouse";
            colWarehouse.MinimumWidth = 6;
            colWarehouse.Name = "colWarehouse";
            colWarehouse.Width = 125;
            // 
            // btnEdit
            // 
            btnEdit.BackColor = Color.Yellow;
            btnEdit.FlatStyle = FlatStyle.Flat;
            btnEdit.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEdit.Location = new Point(1227, 300);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(76, 31);
            btnEdit.TabIndex = 26;
            btnEdit.Text = "Edit";
            btnEdit.UseVisualStyleBackColor = false;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.Red;
            btnDelete.FlatStyle = FlatStyle.Flat;
            btnDelete.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDelete.ForeColor = Color.Black;
            btnDelete.Location = new Point(1309, 300);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(76, 31);
            btnDelete.TabIndex = 27;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = false;
            // 
            // Product
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1776, 860);
            Controls.Add(btnDelete);
            Controls.Add(btnEdit);
            Controls.Add(txtSearch);
            Controls.Add(label12);
            Controls.Add(label10);
            Controls.Add(txtQuantity);
            Controls.Add(label11);
            Controls.Add(txtPrice);
            Controls.Add(label8);
            Controls.Add(txtWarehouse);
            Controls.Add(dataProductList);
            Controls.Add(label6);
            Controls.Add(btnAdd);
            Controls.Add(label5);
            Controls.Add(textBox4);
            Controls.Add(label4);
            Controls.Add(txtAttribute);
            Controls.Add(label3);
            Controls.Add(textBox2);
            Controls.Add(label2);
            Controls.Add(txtProductName);
            Controls.Add(label1);
            Controls.Add(groupBox1);
            Name = "Product";
            Text = "Product";
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataProductList).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private Button btnDashboard;
        private PictureBox pictureBox1;
        private Button btnAttributes;
        private Button btnBrands;
        private Button btnCategory;
        private Label label1;
        private TextBox txtProductName;
        private Label label2;
        private Label label3;
        private TextBox textBox2;
        private Label label4;
        private TextBox txtAttribute;
        private Label label5;
        private TextBox textBox4;
        private Button btnSales;
        private Button btnProduct;
        private Button btnAdd;
        private Label label6;
        private Button btnReport;
        private Button btnInventory;
        private DataGridView dataProductList;
        private Label label8;
        private TextBox txtWarehouse;
        private Label label10;
        private TextBox txtQuantity;
        private Label label11;
        private TextBox txtPrice;
        private Label label12;
        private TextBox txtSearch;
        private DataGridViewTextBoxColumn colProduct;
        private DataGridViewTextBoxColumn colCategory;
        private DataGridViewTextBoxColumn colBrand;
        private DataGridViewTextBoxColumn colAttribute;
        private DataGridViewTextBoxColumn colPrice;
        private DataGridViewTextBoxColumn colQuantity;
        private DataGridViewTextBoxColumn colWarehouse;
        private Button btnEdit;
        private Button btnDelete;
    }
}
