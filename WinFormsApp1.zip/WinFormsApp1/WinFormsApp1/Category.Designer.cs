﻿namespace PuffSiteInvSys
{
    partial class Category
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            textBox8 = new TextBox();
            label11 = new Label();
            textBox9 = new TextBox();
            label7 = new Label();
            textBox5 = new TextBox();
            label8 = new Label();
            textBox6 = new TextBox();
            button5 = new Button();
            label5 = new Label();
            textBox4 = new TextBox();
            label4 = new Label();
            textBox3 = new TextBox();
            label3 = new Label();
            textBox2 = new TextBox();
            label2 = new Label();
            textBox1 = new TextBox();
            label1 = new Label();
            comboBox1 = new ComboBox();
            btnDelete = new Button();
            btnEdit = new Button();
            txtSearch = new TextBox();
            label12 = new Label();
            dataProductList = new DataGridView();
            colProduct = new DataGridViewTextBoxColumn();
            colCategory = new DataGridViewTextBoxColumn();
            colBrand = new DataGridViewTextBoxColumn();
            colAttribute = new DataGridViewTextBoxColumn();
            colPrice = new DataGridViewTextBoxColumn();
            colQuantity = new DataGridViewTextBoxColumn();
            colWarehouse = new DataGridViewTextBoxColumn();
            label6 = new Label();
            label9 = new Label();
            groupBox1 = new GroupBox();
            btnReport = new Button();
            btnInventory = new Button();
            btnSales = new Button();
            btnProduct = new Button();
            btnAttributes = new Button();
            btnBrands = new Button();
            btnCategory = new Button();
            pictureBox1 = new PictureBox();
            btnDashboard = new Button();
            ((System.ComponentModel.ISupportInitialize)dataProductList).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // textBox8
            // 
            textBox8.Location = new Point(761, -87);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(125, 27);
            textBox8.TabIndex = 45;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(711, -116);
            label11.Name = "label11";
            label11.Size = new Size(44, 20);
            label11.TabIndex = 44;
            label11.Text = "Price:";
            // 
            // textBox9
            // 
            textBox9.Location = new Point(761, -120);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(125, 27);
            textBox9.TabIndex = 43;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(464, -54);
            label7.Name = "label7";
            label7.Size = new Size(72, 20);
            label7.TabIndex = 42;
            label7.Text = "Category:";
            // 
            // textBox5
            // 
            textBox5.Location = new Point(542, -57);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(125, 27);
            textBox5.TabIndex = 41;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(451, -87);
            label8.Name = "label8";
            label8.Size = new Size(85, 20);
            label8.TabIndex = 40;
            label8.Text = "Warehouse:";
            // 
            // textBox6
            // 
            textBox6.Location = new Point(542, -90);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(125, 27);
            textBox6.TabIndex = 39;
            // 
            // button5
            // 
            button5.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button5.Location = new Point(778, -43);
            button5.Name = "button5";
            button5.Size = new Size(91, 43);
            button5.TabIndex = 36;
            button5.Text = "Add";
            button5.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(218, -54);
            label5.Name = "label5";
            label5.Size = new Size(72, 20);
            label5.TabIndex = 35;
            label5.Text = "Category:";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(296, -57);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(125, 27);
            textBox4.TabIndex = 34;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(459, -120);
            label4.Name = "label4";
            label4.Size = new Size(77, 20);
            label4.TabIndex = 33;
            label4.Text = "Attributes:";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(542, -123);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(125, 27);
            textBox3.TabIndex = 32;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(233, -87);
            label3.Name = "label3";
            label3.Size = new Size(57, 20);
            label3.TabIndex = 31;
            label3.Text = "Brands:";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(296, -90);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(125, 27);
            textBox2.TabIndex = 30;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(238, -120);
            label2.Name = "label2";
            label2.Size = new Size(52, 20);
            label2.TabIndex = 29;
            label2.Text = "Name:";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(296, -123);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(125, 27);
            textBox1.TabIndex = 28;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(175, -163);
            label1.Name = "label1";
            label1.Size = new Size(126, 28);
            label1.TabIndex = 27;
            label1.Text = "Add Product";
            // 
            // comboBox1
            // 
            comboBox1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "E-Liquids", "Vape Pens", "Mods", "Tanks", "Coils", "Batteries", "Accessories", "Kits" });
            comboBox1.Location = new Point(418, 63);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(151, 36);
            comboBox1.TabIndex = 50;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.Red;
            btnDelete.FlatStyle = FlatStyle.Flat;
            btnDelete.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDelete.ForeColor = Color.Black;
            btnDelete.Location = new Point(1309, 297);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(76, 31);
            btnDelete.TabIndex = 56;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = false;
            // 
            // btnEdit
            // 
            btnEdit.BackColor = Color.Yellow;
            btnEdit.FlatStyle = FlatStyle.Flat;
            btnEdit.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEdit.Location = new Point(1227, 297);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(76, 31);
            btnEdit.TabIndex = 55;
            btnEdit.Text = "Edit";
            btnEdit.UseVisualStyleBackColor = false;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(1096, 257);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(125, 27);
            txtSearch.TabIndex = 54;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.Location = new Point(1022, 259);
            label12.Name = "label12";
            label12.Size = new Size(68, 25);
            label12.TabIndex = 53;
            label12.Text = "Search:";
            // 
            // dataProductList
            // 
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataProductList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dataProductList.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataProductList.Columns.AddRange(new DataGridViewColumn[] { colProduct, colCategory, colBrand, colAttribute, colPrice, colQuantity, colWarehouse });
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dataProductList.DefaultCellStyle = dataGridViewCellStyle2;
            dataProductList.Location = new Point(294, 297);
            dataProductList.Name = "dataProductList";
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = SystemColors.Control;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            dataProductList.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dataProductList.RowHeadersWidth = 51;
            dataProductList.Size = new Size(927, 555);
            dataProductList.TabIndex = 52;
            // 
            // colProduct
            // 
            colProduct.HeaderText = "Product";
            colProduct.MinimumWidth = 6;
            colProduct.Name = "colProduct";
            colProduct.Width = 125;
            // 
            // colCategory
            // 
            colCategory.HeaderText = "Category";
            colCategory.MinimumWidth = 6;
            colCategory.Name = "colCategory";
            colCategory.Width = 125;
            // 
            // colBrand
            // 
            colBrand.HeaderText = "Brand";
            colBrand.MinimumWidth = 6;
            colBrand.Name = "colBrand";
            colBrand.Width = 125;
            // 
            // colAttribute
            // 
            colAttribute.HeaderText = "Attribute";
            colAttribute.MinimumWidth = 6;
            colAttribute.Name = "colAttribute";
            colAttribute.Width = 125;
            // 
            // colPrice
            // 
            colPrice.HeaderText = "Price";
            colPrice.MinimumWidth = 6;
            colPrice.Name = "colPrice";
            colPrice.Width = 125;
            // 
            // colQuantity
            // 
            colQuantity.HeaderText = "Quantity";
            colQuantity.MinimumWidth = 6;
            colQuantity.Name = "colQuantity";
            colQuantity.Width = 125;
            // 
            // colWarehouse
            // 
            colWarehouse.HeaderText = "Warehouse";
            colWarehouse.MinimumWidth = 6;
            colWarehouse.Name = "colWarehouse";
            colWarehouse.Width = 125;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(294, 256);
            label6.Name = "label6";
            label6.Size = new Size(130, 28);
            label6.TabIndex = 51;
            label6.Text = "Product List:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(295, 66);
            label9.Name = "label9";
            label9.Size = new Size(117, 28);
            label9.TabIndex = 57;
            label9.Text = "Categories:";
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Chartreuse;
            groupBox1.Controls.Add(btnReport);
            groupBox1.Controls.Add(btnInventory);
            groupBox1.Controls.Add(btnSales);
            groupBox1.Controls.Add(btnProduct);
            groupBox1.Controls.Add(btnAttributes);
            groupBox1.Controls.Add(btnBrands);
            groupBox1.Controls.Add(btnCategory);
            groupBox1.Controls.Add(pictureBox1);
            groupBox1.Controls.Add(btnDashboard);
            groupBox1.Location = new Point(4, 3);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(239, 864);
            groupBox1.TabIndex = 58;
            groupBox1.TabStop = false;
            groupBox1.Text = "groupBox1";
            // 
            // btnReport
            // 
            btnReport.BackColor = Color.Chartreuse;
            btnReport.FlatAppearance.BorderSize = 0;
            btnReport.FlatStyle = FlatStyle.Flat;
            btnReport.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnReport.ForeColor = Color.Purple;
            btnReport.Location = new Point(0, 784);
            btnReport.Name = "btnReport";
            btnReport.Size = new Size(239, 80);
            btnReport.TabIndex = 15;
            btnReport.Text = "REPORT";
            btnReport.UseVisualStyleBackColor = false;
            // 
            // btnInventory
            // 
            btnInventory.BackColor = Color.Chartreuse;
            btnInventory.FlatAppearance.BorderSize = 0;
            btnInventory.FlatStyle = FlatStyle.Flat;
            btnInventory.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnInventory.ForeColor = Color.Purple;
            btnInventory.Location = new Point(0, 698);
            btnInventory.Name = "btnInventory";
            btnInventory.Size = new Size(239, 80);
            btnInventory.TabIndex = 14;
            btnInventory.Text = "INVENTORY";
            btnInventory.UseVisualStyleBackColor = false;
            // 
            // btnSales
            // 
            btnSales.BackColor = Color.Chartreuse;
            btnSales.FlatAppearance.BorderSize = 0;
            btnSales.FlatStyle = FlatStyle.Flat;
            btnSales.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSales.ForeColor = Color.Purple;
            btnSales.Location = new Point(0, 612);
            btnSales.Name = "btnSales";
            btnSales.Size = new Size(239, 80);
            btnSales.TabIndex = 13;
            btnSales.Text = "SALES";
            btnSales.UseVisualStyleBackColor = false;
            // 
            // btnProduct
            // 
            btnProduct.BackColor = Color.Chartreuse;
            btnProduct.FlatAppearance.BorderSize = 0;
            btnProduct.FlatStyle = FlatStyle.Flat;
            btnProduct.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnProduct.ForeColor = Color.Purple;
            btnProduct.Location = new Point(0, 526);
            btnProduct.Name = "btnProduct";
            btnProduct.Size = new Size(239, 80);
            btnProduct.TabIndex = 5;
            btnProduct.Text = "PRODUCT";
            btnProduct.UseVisualStyleBackColor = false;
            // 
            // btnAttributes
            // 
            btnAttributes.BackColor = Color.Chartreuse;
            btnAttributes.FlatAppearance.BorderSize = 0;
            btnAttributes.FlatStyle = FlatStyle.Flat;
            btnAttributes.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAttributes.ForeColor = Color.Purple;
            btnAttributes.Location = new Point(0, 440);
            btnAttributes.Name = "btnAttributes";
            btnAttributes.Size = new Size(239, 80);
            btnAttributes.TabIndex = 4;
            btnAttributes.Text = "ATTRIBUTES";
            btnAttributes.UseVisualStyleBackColor = false;
            // 
            // btnBrands
            // 
            btnBrands.BackColor = Color.Chartreuse;
            btnBrands.FlatAppearance.BorderSize = 0;
            btnBrands.FlatStyle = FlatStyle.Flat;
            btnBrands.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBrands.ForeColor = Color.Purple;
            btnBrands.Location = new Point(0, 354);
            btnBrands.Name = "btnBrands";
            btnBrands.Size = new Size(239, 80);
            btnBrands.TabIndex = 3;
            btnBrands.Text = "BRANDS";
            btnBrands.UseVisualStyleBackColor = false;
            // 
            // btnCategory
            // 
            btnCategory.BackColor = Color.Chartreuse;
            btnCategory.FlatAppearance.BorderSize = 0;
            btnCategory.FlatStyle = FlatStyle.Flat;
            btnCategory.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCategory.ForeColor = Color.Purple;
            btnCategory.Location = new Point(0, 268);
            btnCategory.Name = "btnCategory";
            btnCategory.Size = new Size(239, 80);
            btnCategory.TabIndex = 2;
            btnCategory.Text = "CATEGORY";
            btnCategory.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Puff_Site_Logo;
            pictureBox1.Location = new Point(0, -1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(239, 177);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // btnDashboard
            // 
            btnDashboard.BackColor = Color.Chartreuse;
            btnDashboard.FlatAppearance.BorderSize = 0;
            btnDashboard.FlatStyle = FlatStyle.Flat;
            btnDashboard.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDashboard.ForeColor = Color.Purple;
            btnDashboard.Location = new Point(0, 182);
            btnDashboard.Name = "btnDashboard";
            btnDashboard.Size = new Size(239, 80);
            btnDashboard.TabIndex = 0;
            btnDashboard.Text = "DASHBOARD";
            btnDashboard.UseVisualStyleBackColor = false;
            // 
            // Category
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1775, 864);
            Controls.Add(groupBox1);
            Controls.Add(label9);
            Controls.Add(btnDelete);
            Controls.Add(btnEdit);
            Controls.Add(txtSearch);
            Controls.Add(label12);
            Controls.Add(dataProductList);
            Controls.Add(label6);
            Controls.Add(comboBox1);
            Controls.Add(textBox8);
            Controls.Add(label11);
            Controls.Add(textBox9);
            Controls.Add(label7);
            Controls.Add(textBox5);
            Controls.Add(label8);
            Controls.Add(textBox6);
            Controls.Add(button5);
            Controls.Add(label5);
            Controls.Add(textBox4);
            Controls.Add(label4);
            Controls.Add(textBox3);
            Controls.Add(label3);
            Controls.Add(textBox2);
            Controls.Add(label2);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Name = "Category";
            Text = "Category";
            Load += Inventory_Load;
            ((System.ComponentModel.ISupportInitialize)dataProductList).EndInit();
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox textBox8;
        private Label label11;
        private TextBox textBox9;
        private Label label7;
        private TextBox textBox5;
        private Label label8;
        private TextBox textBox6;
        private Button button5;
        private Label label5;
        private TextBox textBox4;
        private Label label4;
        private TextBox textBox3;
        private Label label3;
        private TextBox textBox2;
        private Label label2;
        private TextBox textBox1;
        private Label label1;
        private ComboBox comboBox1;
        private Button btnDelete;
        private Button btnEdit;
        private TextBox txtSearch;
        private Label label12;
        private DataGridView dataProductList;
        private DataGridViewTextBoxColumn colProduct;
        private DataGridViewTextBoxColumn colCategory;
        private DataGridViewTextBoxColumn colBrand;
        private DataGridViewTextBoxColumn colAttribute;
        private DataGridViewTextBoxColumn colPrice;
        private DataGridViewTextBoxColumn colQuantity;
        private DataGridViewTextBoxColumn colWarehouse;
        private Label label6;
        private Label label9;
        private GroupBox groupBox1;
        private Button btnReport;
        private Button btnInventory;
        private Button btnSales;
        private Button btnProduct;
        private Button btnAttributes;
        private Button btnBrands;
        private Button btnCategory;
        private PictureBox pictureBox1;
        private Button btnDashboard;
    }
}