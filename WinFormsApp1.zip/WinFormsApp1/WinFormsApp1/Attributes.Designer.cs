﻿namespace PuffSiteInvSys
{
    partial class Attributes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            groupBox1 = new GroupBox();
            btnReport = new Button();
            btnInventory = new Button();
            btnSales = new Button();
            btnProduct = new Button();
            btnAttributes = new Button();
            btnBrands = new Button();
            btnCategory = new Button();
            pictureBox1 = new PictureBox();
            btnDashboard = new Button();
            label9 = new Label();
            btnDelete = new Button();
            btnEdit = new Button();
            txtSearch = new TextBox();
            label12 = new Label();
            dataProductList = new DataGridView();
            colProduct = new DataGridViewTextBoxColumn();
            colCategory = new DataGridViewTextBoxColumn();
            colBrand = new DataGridViewTextBoxColumn();
            colAttribute = new DataGridViewTextBoxColumn();
            colPrice = new DataGridViewTextBoxColumn();
            colQuantity = new DataGridViewTextBoxColumn();
            colWarehouse = new DataGridViewTextBoxColumn();
            label6 = new Label();
            label10 = new Label();
            txtQuantity = new TextBox();
            label11 = new Label();
            txtPrice = new TextBox();
            label5 = new Label();
            textBox4 = new TextBox();
            label4 = new Label();
            txtAttribute = new TextBox();
            label3 = new Label();
            textBox2 = new TextBox();
            label2 = new Label();
            txtProductName = new TextBox();
            btnFilter = new Button();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataProductList).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Chartreuse;
            groupBox1.Controls.Add(btnReport);
            groupBox1.Controls.Add(btnInventory);
            groupBox1.Controls.Add(btnSales);
            groupBox1.Controls.Add(btnProduct);
            groupBox1.Controls.Add(btnAttributes);
            groupBox1.Controls.Add(btnBrands);
            groupBox1.Controls.Add(btnCategory);
            groupBox1.Controls.Add(pictureBox1);
            groupBox1.Controls.Add(btnDashboard);
            groupBox1.Location = new Point(5, 4);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(239, 864);
            groupBox1.TabIndex = 76;
            groupBox1.TabStop = false;
            groupBox1.Text = "groupBox1";
            // 
            // btnReport
            // 
            btnReport.BackColor = Color.Chartreuse;
            btnReport.FlatAppearance.BorderSize = 0;
            btnReport.FlatStyle = FlatStyle.Flat;
            btnReport.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnReport.ForeColor = Color.Purple;
            btnReport.Location = new Point(0, 784);
            btnReport.Name = "btnReport";
            btnReport.Size = new Size(239, 80);
            btnReport.TabIndex = 15;
            btnReport.Text = "REPORT";
            btnReport.UseVisualStyleBackColor = false;
            // 
            // btnInventory
            // 
            btnInventory.BackColor = Color.Chartreuse;
            btnInventory.FlatAppearance.BorderSize = 0;
            btnInventory.FlatStyle = FlatStyle.Flat;
            btnInventory.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnInventory.ForeColor = Color.Purple;
            btnInventory.Location = new Point(0, 698);
            btnInventory.Name = "btnInventory";
            btnInventory.Size = new Size(239, 80);
            btnInventory.TabIndex = 14;
            btnInventory.Text = "INVENTORY";
            btnInventory.UseVisualStyleBackColor = false;
            // 
            // btnSales
            // 
            btnSales.BackColor = Color.Chartreuse;
            btnSales.FlatAppearance.BorderSize = 0;
            btnSales.FlatStyle = FlatStyle.Flat;
            btnSales.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSales.ForeColor = Color.Purple;
            btnSales.Location = new Point(0, 612);
            btnSales.Name = "btnSales";
            btnSales.Size = new Size(239, 80);
            btnSales.TabIndex = 13;
            btnSales.Text = "SALES";
            btnSales.UseVisualStyleBackColor = false;
            // 
            // btnProduct
            // 
            btnProduct.BackColor = Color.Chartreuse;
            btnProduct.FlatAppearance.BorderSize = 0;
            btnProduct.FlatStyle = FlatStyle.Flat;
            btnProduct.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnProduct.ForeColor = Color.Purple;
            btnProduct.Location = new Point(0, 526);
            btnProduct.Name = "btnProduct";
            btnProduct.Size = new Size(239, 80);
            btnProduct.TabIndex = 5;
            btnProduct.Text = "PRODUCT";
            btnProduct.UseVisualStyleBackColor = false;
            // 
            // btnAttributes
            // 
            btnAttributes.BackColor = Color.Chartreuse;
            btnAttributes.FlatAppearance.BorderSize = 0;
            btnAttributes.FlatStyle = FlatStyle.Flat;
            btnAttributes.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAttributes.ForeColor = Color.Purple;
            btnAttributes.Location = new Point(0, 440);
            btnAttributes.Name = "btnAttributes";
            btnAttributes.Size = new Size(239, 80);
            btnAttributes.TabIndex = 4;
            btnAttributes.Text = "ATTRIBUTES";
            btnAttributes.UseVisualStyleBackColor = false;
            // 
            // btnBrands
            // 
            btnBrands.BackColor = Color.Chartreuse;
            btnBrands.FlatAppearance.BorderSize = 0;
            btnBrands.FlatStyle = FlatStyle.Flat;
            btnBrands.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBrands.ForeColor = Color.Purple;
            btnBrands.Location = new Point(0, 354);
            btnBrands.Name = "btnBrands";
            btnBrands.Size = new Size(239, 80);
            btnBrands.TabIndex = 3;
            btnBrands.Text = "BRANDS";
            btnBrands.UseVisualStyleBackColor = false;
            // 
            // btnCategory
            // 
            btnCategory.BackColor = Color.Chartreuse;
            btnCategory.FlatAppearance.BorderSize = 0;
            btnCategory.FlatStyle = FlatStyle.Flat;
            btnCategory.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCategory.ForeColor = Color.Purple;
            btnCategory.Location = new Point(0, 268);
            btnCategory.Name = "btnCategory";
            btnCategory.Size = new Size(239, 80);
            btnCategory.TabIndex = 2;
            btnCategory.Text = "CATEGORY";
            btnCategory.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Puff_Site_Logo;
            pictureBox1.Location = new Point(0, -1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(239, 177);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // btnDashboard
            // 
            btnDashboard.BackColor = Color.Chartreuse;
            btnDashboard.FlatAppearance.BorderSize = 0;
            btnDashboard.FlatStyle = FlatStyle.Flat;
            btnDashboard.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDashboard.ForeColor = Color.Purple;
            btnDashboard.Location = new Point(0, 182);
            btnDashboard.Name = "btnDashboard";
            btnDashboard.Size = new Size(239, 80);
            btnDashboard.TabIndex = 0;
            btnDashboard.Text = "DASHBOARD";
            btnDashboard.UseVisualStyleBackColor = false;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(295, 29);
            label9.Name = "label9";
            label9.Size = new Size(123, 31);
            label9.TabIndex = 75;
            label9.Text = "Attributes";
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.Red;
            btnDelete.FlatStyle = FlatStyle.Flat;
            btnDelete.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDelete.ForeColor = Color.Black;
            btnDelete.Location = new Point(1310, 298);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(76, 31);
            btnDelete.TabIndex = 74;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = false;
            // 
            // btnEdit
            // 
            btnEdit.BackColor = Color.Yellow;
            btnEdit.FlatStyle = FlatStyle.Flat;
            btnEdit.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEdit.Location = new Point(1228, 298);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(76, 31);
            btnEdit.TabIndex = 73;
            btnEdit.Text = "Edit";
            btnEdit.UseVisualStyleBackColor = false;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(1097, 258);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(125, 27);
            txtSearch.TabIndex = 72;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.Location = new Point(1023, 260);
            label12.Name = "label12";
            label12.Size = new Size(68, 25);
            label12.TabIndex = 71;
            label12.Text = "Search:";
            // 
            // dataProductList
            // 
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataProductList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dataProductList.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataProductList.Columns.AddRange(new DataGridViewColumn[] { colProduct, colCategory, colBrand, colAttribute, colPrice, colQuantity, colWarehouse });
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dataProductList.DefaultCellStyle = dataGridViewCellStyle2;
            dataProductList.Location = new Point(295, 298);
            dataProductList.Name = "dataProductList";
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = SystemColors.Control;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            dataProductList.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dataProductList.RowHeadersWidth = 51;
            dataProductList.Size = new Size(927, 555);
            dataProductList.TabIndex = 70;
            // 
            // colProduct
            // 
            colProduct.HeaderText = "Product";
            colProduct.MinimumWidth = 6;
            colProduct.Name = "colProduct";
            colProduct.Width = 125;
            // 
            // colCategory
            // 
            colCategory.HeaderText = "Category";
            colCategory.MinimumWidth = 6;
            colCategory.Name = "colCategory";
            colCategory.Width = 125;
            // 
            // colBrand
            // 
            colBrand.HeaderText = "Brand";
            colBrand.MinimumWidth = 6;
            colBrand.Name = "colBrand";
            colBrand.Width = 125;
            // 
            // colAttribute
            // 
            colAttribute.HeaderText = "Attribute";
            colAttribute.MinimumWidth = 6;
            colAttribute.Name = "colAttribute";
            colAttribute.Width = 125;
            // 
            // colPrice
            // 
            colPrice.HeaderText = "Price";
            colPrice.MinimumWidth = 6;
            colPrice.Name = "colPrice";
            colPrice.Width = 125;
            // 
            // colQuantity
            // 
            colQuantity.HeaderText = "Quantity";
            colQuantity.MinimumWidth = 6;
            colQuantity.Name = "colQuantity";
            colQuantity.Width = 125;
            // 
            // colWarehouse
            // 
            colWarehouse.HeaderText = "Warehouse";
            colWarehouse.MinimumWidth = 6;
            colWarehouse.Name = "colWarehouse";
            colWarehouse.Width = 125;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(295, 257);
            label6.Name = "label6";
            label6.Size = new Size(130, 28);
            label6.TabIndex = 69;
            label6.Text = "Product List:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 10.2F);
            label10.Location = new Point(345, 152);
            label10.Name = "label10";
            label10.Size = new Size(109, 23);
            label10.TabIndex = 88;
            label10.Text = "Size/Volume:";
            // 
            // txtQuantity
            // 
            txtQuantity.Font = new Font("Segoe UI", 10.2F);
            txtQuantity.Location = new Point(460, 148);
            txtQuantity.Name = "txtQuantity";
            txtQuantity.Size = new Size(125, 30);
            txtQuantity.TabIndex = 87;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 10.2F);
            label11.Location = new Point(306, 115);
            label11.Name = "label11";
            label11.Size = new Size(148, 23);
            label11.TabIndex = 86;
            label11.Text = "Nicotine Strength:";
            // 
            // txtPrice
            // 
            txtPrice.Font = new Font("Segoe UI", 10.2F);
            txtPrice.Location = new Point(460, 112);
            txtPrice.Name = "txtPrice";
            txtPrice.Size = new Size(125, 30);
            txtPrice.TabIndex = 85;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10.2F);
            label5.Location = new Point(735, 79);
            label5.Name = "label5";
            label5.Size = new Size(55, 23);
            label5.TabIndex = 84;
            label5.Text = "Color:";
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Segoe UI", 10.2F);
            textBox4.Location = new Point(796, 76);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(125, 30);
            textBox4.TabIndex = 83;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10.2F);
            label4.Location = new Point(691, 152);
            label4.Name = "label4";
            label4.Size = new Size(99, 23);
            label4.TabIndex = 82;
            label4.Text = "Battery Life:";
            // 
            // txtAttribute
            // 
            txtAttribute.Font = new Font("Segoe UI", 10.2F);
            txtAttribute.Location = new Point(796, 148);
            txtAttribute.Name = "txtAttribute";
            txtAttribute.Size = new Size(125, 30);
            txtAttribute.TabIndex = 81;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10.2F);
            label3.Location = new Point(659, 115);
            label3.Name = "label3";
            label3.Size = new Size(131, 23);
            label3.TabIndex = 80;
            label3.Text = "Wattage Range:";
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Segoe UI", 10.2F);
            textBox2.Location = new Point(796, 112);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(125, 30);
            textBox2.TabIndex = 79;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10.2F);
            label2.Location = new Point(385, 79);
            label2.Name = "label2";
            label2.Size = new Size(69, 23);
            label2.TabIndex = 78;
            label2.Text = "Flavour:";
            // 
            // txtProductName
            // 
            txtProductName.Font = new Font("Segoe UI", 10.2F);
            txtProductName.Location = new Point(460, 76);
            txtProductName.Name = "txtProductName";
            txtProductName.Size = new Size(125, 30);
            txtProductName.TabIndex = 77;
            // 
            // btnFilter
            // 
            btnFilter.BackColor = Color.FromArgb(192, 255, 255);
            btnFilter.FlatAppearance.BorderColor = Color.Cyan;
            btnFilter.FlatAppearance.BorderSize = 2;
            btnFilter.FlatStyle = FlatStyle.Flat;
            btnFilter.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnFilter.ForeColor = Color.Black;
            btnFilter.Location = new Point(962, 95);
            btnFilter.Name = "btnFilter";
            btnFilter.Size = new Size(91, 43);
            btnFilter.TabIndex = 89;
            btnFilter.Text = "Filter";
            btnFilter.UseVisualStyleBackColor = false;
            // 
            // Attributes
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1777, 865);
            Controls.Add(btnFilter);
            Controls.Add(label10);
            Controls.Add(txtQuantity);
            Controls.Add(label11);
            Controls.Add(txtPrice);
            Controls.Add(label5);
            Controls.Add(textBox4);
            Controls.Add(label4);
            Controls.Add(txtAttribute);
            Controls.Add(label3);
            Controls.Add(textBox2);
            Controls.Add(label2);
            Controls.Add(txtProductName);
            Controls.Add(groupBox1);
            Controls.Add(label9);
            Controls.Add(btnDelete);
            Controls.Add(btnEdit);
            Controls.Add(txtSearch);
            Controls.Add(label12);
            Controls.Add(dataProductList);
            Controls.Add(label6);
            Name = "Attributes";
            Text = "Attributes";
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataProductList).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private Button btnReport;
        private Button btnInventory;
        private Button btnSales;
        private Button btnProduct;
        private Button btnAttributes;
        private Button btnBrands;
        private Button btnCategory;
        private PictureBox pictureBox1;
        private Button btnDashboard;
        private Label label9;
        private Button btnDelete;
        private Button btnEdit;
        private TextBox txtSearch;
        private Label label12;
        private DataGridView dataProductList;
        private DataGridViewTextBoxColumn colProduct;
        private DataGridViewTextBoxColumn colCategory;
        private DataGridViewTextBoxColumn colBrand;
        private DataGridViewTextBoxColumn colAttribute;
        private DataGridViewTextBoxColumn colPrice;
        private DataGridViewTextBoxColumn colQuantity;
        private DataGridViewTextBoxColumn colWarehouse;
        private Label label6;
        private Label label10;
        private TextBox txtQuantity;
        private Label label11;
        private TextBox txtPrice;
        private Label label5;
        private TextBox textBox4;
        private Label label4;
        private TextBox txtAttribute;
        private Label label3;
        private TextBox textBox2;
        private Label label2;
        private TextBox txtProductName;
        private Button btnFilter;
    }
}