﻿namespace PuffSiteInvSys
{
    partial class Brands
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            groupBox1 = new GroupBox();
            btnReport = new Button();
            btnInventory = new Button();
            btnSales = new Button();
            btnProduct = new Button();
            btnAttributes = new Button();
            btnBrands = new Button();
            btnCategory = new Button();
            pictureBox1 = new PictureBox();
            btnDashboard = new Button();
            label9 = new Label();
            btnDelete = new Button();
            btnEdit = new Button();
            txtSearch = new TextBox();
            label12 = new Label();
            dataProductList = new DataGridView();
            colProduct = new DataGridViewTextBoxColumn();
            colCategory = new DataGridViewTextBoxColumn();
            colBrand = new DataGridViewTextBoxColumn();
            colAttribute = new DataGridViewTextBoxColumn();
            colPrice = new DataGridViewTextBoxColumn();
            colQuantity = new DataGridViewTextBoxColumn();
            colWarehouse = new DataGridViewTextBoxColumn();
            label6 = new Label();
            comboBox1 = new ComboBox();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataProductList).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Chartreuse;
            groupBox1.Controls.Add(btnReport);
            groupBox1.Controls.Add(btnInventory);
            groupBox1.Controls.Add(btnSales);
            groupBox1.Controls.Add(btnProduct);
            groupBox1.Controls.Add(btnAttributes);
            groupBox1.Controls.Add(btnBrands);
            groupBox1.Controls.Add(btnCategory);
            groupBox1.Controls.Add(pictureBox1);
            groupBox1.Controls.Add(btnDashboard);
            groupBox1.Location = new Point(2, 2);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(239, 864);
            groupBox1.TabIndex = 67;
            groupBox1.TabStop = false;
            groupBox1.Text = "groupBox1";
            // 
            // btnReport
            // 
            btnReport.BackColor = Color.Chartreuse;
            btnReport.FlatAppearance.BorderSize = 0;
            btnReport.FlatStyle = FlatStyle.Flat;
            btnReport.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnReport.ForeColor = Color.Purple;
            btnReport.Location = new Point(0, 784);
            btnReport.Name = "btnReport";
            btnReport.Size = new Size(239, 80);
            btnReport.TabIndex = 15;
            btnReport.Text = "REPORT";
            btnReport.UseVisualStyleBackColor = false;
            // 
            // btnInventory
            // 
            btnInventory.BackColor = Color.Chartreuse;
            btnInventory.FlatAppearance.BorderSize = 0;
            btnInventory.FlatStyle = FlatStyle.Flat;
            btnInventory.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnInventory.ForeColor = Color.Purple;
            btnInventory.Location = new Point(0, 698);
            btnInventory.Name = "btnInventory";
            btnInventory.Size = new Size(239, 80);
            btnInventory.TabIndex = 14;
            btnInventory.Text = "INVENTORY";
            btnInventory.UseVisualStyleBackColor = false;
            // 
            // btnSales
            // 
            btnSales.BackColor = Color.Chartreuse;
            btnSales.FlatAppearance.BorderSize = 0;
            btnSales.FlatStyle = FlatStyle.Flat;
            btnSales.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSales.ForeColor = Color.Purple;
            btnSales.Location = new Point(0, 612);
            btnSales.Name = "btnSales";
            btnSales.Size = new Size(239, 80);
            btnSales.TabIndex = 13;
            btnSales.Text = "SALES";
            btnSales.UseVisualStyleBackColor = false;
            // 
            // btnProduct
            // 
            btnProduct.BackColor = Color.Chartreuse;
            btnProduct.FlatAppearance.BorderSize = 0;
            btnProduct.FlatStyle = FlatStyle.Flat;
            btnProduct.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnProduct.ForeColor = Color.Purple;
            btnProduct.Location = new Point(0, 526);
            btnProduct.Name = "btnProduct";
            btnProduct.Size = new Size(239, 80);
            btnProduct.TabIndex = 5;
            btnProduct.Text = "PRODUCT";
            btnProduct.UseVisualStyleBackColor = false;
            // 
            // btnAttributes
            // 
            btnAttributes.BackColor = Color.Chartreuse;
            btnAttributes.FlatAppearance.BorderSize = 0;
            btnAttributes.FlatStyle = FlatStyle.Flat;
            btnAttributes.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAttributes.ForeColor = Color.Purple;
            btnAttributes.Location = new Point(0, 440);
            btnAttributes.Name = "btnAttributes";
            btnAttributes.Size = new Size(239, 80);
            btnAttributes.TabIndex = 4;
            btnAttributes.Text = "ATTRIBUTES";
            btnAttributes.UseVisualStyleBackColor = false;
            // 
            // btnBrands
            // 
            btnBrands.BackColor = Color.Chartreuse;
            btnBrands.FlatAppearance.BorderSize = 0;
            btnBrands.FlatStyle = FlatStyle.Flat;
            btnBrands.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBrands.ForeColor = Color.Purple;
            btnBrands.Location = new Point(0, 354);
            btnBrands.Name = "btnBrands";
            btnBrands.Size = new Size(239, 80);
            btnBrands.TabIndex = 3;
            btnBrands.Text = "BRANDS";
            btnBrands.UseVisualStyleBackColor = false;
            // 
            // btnCategory
            // 
            btnCategory.BackColor = Color.Chartreuse;
            btnCategory.FlatAppearance.BorderSize = 0;
            btnCategory.FlatStyle = FlatStyle.Flat;
            btnCategory.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCategory.ForeColor = Color.Purple;
            btnCategory.Location = new Point(0, 268);
            btnCategory.Name = "btnCategory";
            btnCategory.Size = new Size(239, 80);
            btnCategory.TabIndex = 2;
            btnCategory.Text = "CATEGORY";
            btnCategory.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Puff_Site_Logo;
            pictureBox1.Location = new Point(0, -1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(239, 177);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // btnDashboard
            // 
            btnDashboard.BackColor = Color.Chartreuse;
            btnDashboard.FlatAppearance.BorderSize = 0;
            btnDashboard.FlatStyle = FlatStyle.Flat;
            btnDashboard.Font = new Font("Courier New", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDashboard.ForeColor = Color.Purple;
            btnDashboard.Location = new Point(0, 182);
            btnDashboard.Name = "btnDashboard";
            btnDashboard.Size = new Size(239, 80);
            btnDashboard.TabIndex = 0;
            btnDashboard.Text = "DASHBOARD";
            btnDashboard.UseVisualStyleBackColor = false;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(292, 61);
            label9.Name = "label9";
            label9.Size = new Size(82, 28);
            label9.TabIndex = 66;
            label9.Text = "Brands:";
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.Red;
            btnDelete.FlatStyle = FlatStyle.Flat;
            btnDelete.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDelete.ForeColor = Color.Black;
            btnDelete.Location = new Point(1307, 296);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(76, 31);
            btnDelete.TabIndex = 65;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = false;
            // 
            // btnEdit
            // 
            btnEdit.BackColor = Color.Yellow;
            btnEdit.FlatStyle = FlatStyle.Flat;
            btnEdit.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEdit.Location = new Point(1225, 296);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(76, 31);
            btnEdit.TabIndex = 64;
            btnEdit.Text = "Edit";
            btnEdit.UseVisualStyleBackColor = false;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(1094, 256);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(125, 27);
            txtSearch.TabIndex = 63;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.Location = new Point(1020, 258);
            label12.Name = "label12";
            label12.Size = new Size(68, 25);
            label12.TabIndex = 62;
            label12.Text = "Search:";
            // 
            // dataProductList
            // 
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataProductList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dataProductList.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataProductList.Columns.AddRange(new DataGridViewColumn[] { colProduct, colCategory, colBrand, colAttribute, colPrice, colQuantity, colWarehouse });
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dataProductList.DefaultCellStyle = dataGridViewCellStyle2;
            dataProductList.Location = new Point(292, 296);
            dataProductList.Name = "dataProductList";
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = SystemColors.Control;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            dataProductList.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dataProductList.RowHeadersWidth = 51;
            dataProductList.Size = new Size(927, 555);
            dataProductList.TabIndex = 61;
            // 
            // colProduct
            // 
            colProduct.HeaderText = "Product";
            colProduct.MinimumWidth = 6;
            colProduct.Name = "colProduct";
            colProduct.Width = 125;
            // 
            // colCategory
            // 
            colCategory.HeaderText = "Category";
            colCategory.MinimumWidth = 6;
            colCategory.Name = "colCategory";
            colCategory.Width = 125;
            // 
            // colBrand
            // 
            colBrand.HeaderText = "Brand";
            colBrand.MinimumWidth = 6;
            colBrand.Name = "colBrand";
            colBrand.Width = 125;
            // 
            // colAttribute
            // 
            colAttribute.HeaderText = "Attribute";
            colAttribute.MinimumWidth = 6;
            colAttribute.Name = "colAttribute";
            colAttribute.Width = 125;
            // 
            // colPrice
            // 
            colPrice.HeaderText = "Price";
            colPrice.MinimumWidth = 6;
            colPrice.Name = "colPrice";
            colPrice.Width = 125;
            // 
            // colQuantity
            // 
            colQuantity.HeaderText = "Quantity";
            colQuantity.MinimumWidth = 6;
            colQuantity.Name = "colQuantity";
            colQuantity.Width = 125;
            // 
            // colWarehouse
            // 
            colWarehouse.HeaderText = "Warehouse";
            colWarehouse.MinimumWidth = 6;
            colWarehouse.Name = "colWarehouse";
            colWarehouse.Width = 125;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(292, 255);
            label6.Name = "label6";
            label6.Size = new Size(130, 28);
            label6.TabIndex = 60;
            label6.Text = "Product List:";
            // 
            // comboBox1
            // 
            comboBox1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "SMOK", "Vaporesso", "GeekVape", "JUUL", "VooPoo", "Aspire", "Innokin", "Eleaf", "Suorin", "Lost Vape" });
            comboBox1.Location = new Point(380, 58);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(151, 36);
            comboBox1.TabIndex = 59;
            // 
            // Brands
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1776, 863);
            Controls.Add(groupBox1);
            Controls.Add(label9);
            Controls.Add(btnDelete);
            Controls.Add(btnEdit);
            Controls.Add(txtSearch);
            Controls.Add(label12);
            Controls.Add(dataProductList);
            Controls.Add(label6);
            Controls.Add(comboBox1);
            Name = "Brands";
            Text = "Brands";
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataProductList).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private Button btnReport;
        private Button btnInventory;
        private Button btnSales;
        private Button btnProduct;
        private Button btnAttributes;
        private Button btnBrands;
        private Button btnCategory;
        private PictureBox pictureBox1;
        private Button btnDashboard;
        private Label label9;
        private Button btnDelete;
        private Button btnEdit;
        private TextBox txtSearch;
        private Label label12;
        private DataGridView dataProductList;
        private DataGridViewTextBoxColumn colProduct;
        private DataGridViewTextBoxColumn colCategory;
        private DataGridViewTextBoxColumn colBrand;
        private DataGridViewTextBoxColumn colAttribute;
        private DataGridViewTextBoxColumn colPrice;
        private DataGridViewTextBoxColumn colQuantity;
        private DataGridViewTextBoxColumn colWarehouse;
        private Label label6;
        private ComboBox comboBox1;
    }
}